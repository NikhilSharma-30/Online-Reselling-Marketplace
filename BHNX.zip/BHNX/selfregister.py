import requests
import json
import re
import argparse
import pdb

REGISTRATION="kratos.belden-horizon.io/self-service/registration/browser"

class User:
    def __init__(self, mail, org, firstname, lastname):
        self.mail = mail
        self.org = org
        self.fn = firstname
        self.ln = lastname

    def get_registration(self, csrf_token):
        return {"traits.email":self.mail,"traits.name.first":self.fn,"traits.name.last":self.ln,"organization":self.org,"phone":"","region":"a865cc45-87a2-11ef-a8f7-3953842796b7","verificationId":"","signUpFlow":True,"password":"TeamF0042","confirmPassword":"TeamF0042","method":"password", "csrf_token": csrf_token}
    def get_user(self, identity_id):
        return {"identityId": identity_id,"email":self.mail,"firstName":self.fn,"lastName":self.ln,"regionId":"a865cc45-87a2-11ef-a8f7-3953842796b7","createdBy":"2e2d9bf2-e666-43a0-970d-e178c5579a5c","createdAt":"2025-12-02T08:35:32.293Z","updatedAt":"2025-12-02T08:35:32.298Z"}

class Registration:
    def __init__(self):
        self.session = requests.Session()

    def getAuthFlow(self):
        return self.session.get(f"https://{REGISTRATION}")

    def register(self, auth_url, user):
        # Extract CSRF Token
        flow_id = auth_url.json().get("id", {})
        print("\nFLOW ID")
        print(flow_id)
        csrf_token = [x.get("attributes").get("value") for x in auth_url.json().get("ui").get("nodes") if x.get("attributes").get("name")=="csrf_token"][0]
        print("\nCSRF TOKEN")
        print(csrf_token)
        # Build Json
        registration = user.get_registration(csrf_token)
        print("\nREGISTRATION JSON")
        print(json.dumps(registration, indent=4))

        # Shoot
        print("\nSTOPPING BEFORE REGISTRATION POST")
        input("Press ENTER to continue...")
        return self.session.post(f"https://kratos.belden-horizon.io/self-service/registration?flow={flow_id}", json=registration)

    def getAuthUrl(self, r):
        flow_id = re.match(".+flow=(.+)", r.url).group(1)
        return self.session.get(f"https://kratos.belden-horizon.io/self-service/registration/flows?id={flow_id}")



def main():
    parser = argparse.ArgumentParser("Create a custom user for SPOG")
    parser.add_argument("--mail", help="Mail for registration",
                        required=True, type=str)
    parser.add_argument("--firstname", help="Firstname of the user to create",
                        default="Tester", type=str)
    parser.add_argument("--lastname", help="Lastname of the user to create",
                        default="Testy", type=str)

    args = parser.parse_args()
    print("=" * 70)
    print("STEP 1 - Script Started")
    print(f"Email      : {args.mail}")
    print(f"Firstname  : {args.firstname}")
    print(f"Lastname   : {args.lastname}")
    print("=" * 70)
    # Read out our ORGS and try to create a user for the first available organisation:
    print("\nSTEP 2 - Discovering Organisation...")
    org = requests.get("https://admin.belden-horizon.io/api/admin/v1/orgs").json()[0].get('name')
    print(f"Organisation Found : {org}")


    # Create a User
    print("\nSTEP 3 - Creating User Object...")
    user = User(args.mail, org, args.firstname, args.lastname)
    print("User Object Created")
    # First we need to use the flow to create our user
    print("\nSTEP 4 - Creating HTTP Session...")
    r=Registration()
    print("HTTP Session Ready")
    print("\nSTEP 5 - Requesting Registration Flow...")
    flow_url = r.getAuthFlow()
    print("Registration Flow Request Completed")
    print(f"HTTP Status : {flow_url.status_code}")
    print(f"Final URL   : {flow_url.url}")
    print("\nSTEP 6 - Requesting Registration Details...")
    auth_url = r.getAuthUrl(flow_url)
    print("\n========== RAW JSON RECEIVED ==========")
    print(auth_url.text[:1500])
    print("======================================")
    print("Registration Details Received")
    print(f"HTTP Status : {auth_url.status_code}")
    request = r.register(auth_url, user)

    # Get Some important ids our identity id 
    identity_id = request.json().get("identity").get("id")
    user_id = request.json().get("id")
    admin_id = requests.get("https://admin.belden-horizon.io/api/admin/v1/roles").json()[0].get("roleId")

    # Then we need the API to also add our user there
    user_create = r.session.post(f"https://admin.belden-horizon.io/api/admin/v1/users", json=user.get_user(identity_id))

    user_id = user_create.json().get("userId")
    admin_id = requests.get("https://admin.belden-horizon.io/api/admin/v1/roles").json()[0].get("roleId")

    pdb.set_trace()
    # Get all organisations that already exist:
    orgs = requests.get("https://admin.belden-horizon.io/api/admin/v1/orgs").json()
    for org in orgs:
        r.session.post(f"https://admin.belden-horizon.io/api/admin/v1/orgs/{org.get('orgId')}/users", json={"userId":user_id, "roleId":admin_id})

    # Get all projects, by going over all users first that exist and make use admin:
    users = [x.get('userId') for x in requests.get("https://admin.belden-horizon.io/api/admin/v1/users").json()]
    projects = set()
    for user in users:
        # Get our projects first
        user_prjs = requests.get(f"https://admin.belden-horizon.io/api/admin/v1/users/{user}/projects")
        if user_prjs.text:
            [ projects.add(x.get("projectId")) for x in user_prjs.json() ]
    for prj in list(projects):
        requests.post(f"https://admin.belden-horizon.io/api/admin/v1/projects/{prj}", json=[{"userId":user_id, "roleId":admin_id}], headers={"userId":user_id})

if __name__ == '__main__':
    main()

