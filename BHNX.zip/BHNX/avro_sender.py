import avro_implementation
import argparse
import asyncio
import netaddr
import uuid

def parse_headers(header_list) -> dict[str, str]:
    headers = { 'User-Agent': 'Go-http-client/1.1' }
    if not header_list:
        return headers
    for h in header_list:
        if ":" not in h:
            raise ValueError(f"Invalid header format (expected 'Key: Value'): {h}")
        k, v = h.split(":", 1)
        headers[k.strip()] = v.strip()
    return headers


async def registration_loop(args:argparse.Namespace):
    mac = netaddr.EUI(args.mac)
    for i in range(0, args.count): # 16’777’215
        mac_transformed = (str(mac).replace("-",":")).lower()
        parameters = {
            'type': "com.nirmata.avro.ClientConnect",
            'sequenceId': f"H{uuid.uuid4()}",
            'source': mac_transformed,
            'clientId': mac_transformed,
            'body': {
                'clientId': mac_transformed,
                'properties': {
                    'serialNumber': mac_transformed,
                    'model': args.model, 
                    'ws_timeout': "30"
                }
              }
        }

        client_connect_protocol = avro_implementation.create_avro_packet(parameters)

        headers = parse_headers(args.header)
        ssl_context = avro_implementation.make_ssl_context(args)
        print(client_connect_protocol.build().hex())
        await avro_implementation.ws_send(
            uri=args.uri,
            host=args.host,
            payload=client_connect_protocol,
            headers=headers,
            ssl_context=ssl_context,
            timeout=args.timeout,
        )

        mac._set_value(mac.value+1)

async def send_notification(args:argparse.Namespace):
    payload_content = ""
    if args.payload_file:
        with open(args.payload_file, 'r') as payload_file:
            payload_content = payload_file.read()
    elif args.payload_string:
        payload_content = args.payload_string
 
    notification_packet = avro_implementation.create_avro_packet(
        type="com.prosoft.avro.NotifyEvent",
        mac_address=args.mac,
        sequenceId=f"H{uuid.uuid4()}",
        payload="".join(payload_content)
    )
    headers = parse_headers(args.header)
    ssl_context = avro_implementation.make_ssl_context(args)
    print(notification_packet.build().hex())
    await avro_implementation.ws_send(
        uri=args.uri,
        host=args.host,
        payload=notification_packet,
        headers=headers,
        ssl_context=ssl_context,
        timeout=args.timeout,
    )

 
async def main():
    parser = argparse.ArgumentParser(
        description="Send binary or text to a WebSocket endpoint."
    )
    parser.add_argument("uri", help="ws:// or wss:// WebSocket URL")
    parser.add_argument("--host", help="Host IP to mimic /etc/hosts settings")

    parser.add_argument("--header", action="append",
                        help="Extra header: 'Key: Value'. Repeatable.")
    parser.add_argument("--insecure", action="store_true",
                        help="Disable TLS certificate verification for wss:// (lab use only).")
    parser.add_argument("--timeout", type=int, default=5,
                        help="Receive timeout in seconds (default: 5).")
    parser.add_argument("--mac", default="a0:b0:86:ff:06:0d", help="Set the mac address to use for packets this")
    subparsers = parser.add_subparsers(title="Packet procedure that you want to run", dest="procedure", metavar="PROC",
                                       help="Select from the following procedures (p1,p2)")
    p1 = subparsers.add_parser(
            "p1",
            help="Send DeviceConnect packets in a loop starting at MAC incrementing by count (Parameter: --count)"
    )
    p1.add_argument("--count", type=int, default=10, help="Amount of packets to send. Each packets mac is incremented by 1, MAX: 1677721")
    p1.add_argument("--model", type=str, default="OpEdge-8D", help="The device modle that is used")
    p1.add_argument("--serial", default=None, type=str, help="Serial number to set")

    p2 = subparsers.add_parser(
            "p2",
            help="Send a NotifyEvent to a Horizon / Spog station"
    )
    payload_group = p2.add_mutually_exclusive_group(required=True)
    payload_group.add_argument("--payload-file", type=str, help="Path to the payload file to send to a horizon station.")
    payload_group.add_argument("--payload-string", type=str, help="Payload string content to send to a horizon station.")


    args = parser.parse_args()

    # No testcase selected
    if not getattr(args, "procedure", None):
        parser.print_help()
        return 2
    if args.procedure == "p1":
        await registration_loop(args)
    elif args.procedure == "p2":
        await send_notification(args)


if __name__ == "__main__":
    asyncio.run(main())


