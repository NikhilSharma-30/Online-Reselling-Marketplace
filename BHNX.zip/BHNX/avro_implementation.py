import struct
import ssl
import asyncio
import argparse
from abc import ABC, abstractmethod
from typing import Optional
# Needs to be pip installed. Ideally in a hatch environment
import websockets
import random
import uuid
import netaddr
from io import BytesIO
from typing import Any, Dict

from fastavro import schemaless_writer, schemaless_reader
from fastavro.schema import parse_schema


class AVROBuilder():
    """
    Base Builder and reader for all AVRO packages (my container class)
    """
    NAMED = {}
    PROTOCOL_COMMAND_MAP = {
      'com.prosoft.avro.SetTimeRequest': parse_schema({
          "type": "record",
          "name": "SetTimeRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SetTimeRequest",
          "fields": [
              {
                  "name": "date",
                  "doc": "date to set on device in format YY-MM-DD",
                  "type": "string"
              },
              {
                  "name": "time",
                  "doc": "time to set on device in format hh:mm:ss",
                  "type": "string"
              },
              {
                  "name": "timezone",
                  "doc": "timezone to set on device in alphabetic format",
                  "type": ["null", "string"],
                  "default": None
              }
          ]
      }
      ),'com.prosoft.avro.FactoryResetResponse': parse_schema({
          "type": "record",
          "name": "FactoryResetResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.FactoryResetResponse",
          "fields": [
              {
                  "name": "message",
                  "type": "string"
              }
          ]
      }
      ),'com.prosoft.avro.GetStatsRequest': parse_schema({
          "type": "record",
          "name": "GetStatsRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.GetStatsRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }
      ),'com.prosoft.avro.OpenRshSessionResponse': parse_schema({
          "type": "record",
          "name": "OpenRshSessionResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.OpenRshSessionResponse",
          "fields": [
              {
                  "name": "message",
                  "type": ["null", "string"],
                  "default": "null"
              }
          ]
      }
      ),'com.prosoft.avro.ConfigurationResult': parse_schema({
          "type": "record",
          "name": "ConfigurationResult",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.ConfigurationResult",
          "fields" : [{
              "name": "module", 
              "type": "string"
          }, {
              "name": "response", 
              "type": "string"
          }]    
      }
      
      ,NAMED),'com.prosoft.avro.SetConfigurationResponse': parse_schema({
      	"type" : "record",
      	"name" : "SetConfigurationResponse",
      	"namespace" : "com.prosoft.avro",
      	"doc" : "Schema for com.prosoft.avro.SetConfigurationResponse",
      	"fields" : [
            {
                "name" : "results",
                "doc" : "The results of the set configuration operation",
                "type" : {
                  "type" : "array",
                  "items" : "com.prosoft.avro.ConfigurationResult"
                }
            }
        ]
      }
      ,NAMED),'com.prosoft.avro.GetCredentialsResponse': parse_schema({
          "type": "record",
          "name": "GetCredentialsResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.GetCredentialsResponse",
          "fields": [
              {
                  "name": "user",
                  "doc": "the user name",
                  "type": "string"
              }, 
              {
                  "name": "password",
                  "doc": "the encrypted password hash",
                  "type": "string"
              },
              {
                  "name": "salt",
                  "doc": "the salt used for hashing the password",
                  "type": "string"
              }
          ]
      }
      ),'com.prosoft.avro.NotifyLoginAttempt': parse_schema({
      	"type": "record",
      	"name": "NotifyLoginAttempt",
      	"namespace": "com.prosoft.avro",
      	"doc": "Schema for com.prosoft.avro.NotifyLoginAttempt",
      	"fields": [
      		{
      			"name": "user",
      			"doc": "the user name",
      			"type": "string"
      		},
      		{
      			"name": "attemptAt",
      			"doc": "attemptAt time of requested login attempt",
      			"type": "string"
      		},
      		{
      			"name": "ip",
      			"doc": "ip address of device from where last login request come",
      			"type": "string"
      		},
      		{
                  "name": "loginStatus",
                  "type": {
                      "type": "enum",
                      "name": "loginStatus",
                      "symbols" : ["FAIL", "RESET", "PASS"]
                  },
                  "default": "FAIL"
              }
      	]
      }),'com.prosoft.avro.SshKeyRequest': parse_schema({
          "type": "record",
          "name": "SshKeyRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SshKeyRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }
      
      ),'com.prosoft.avro.ExportConfigurationResponse': parse_schema({
          "type": "record",
          "name": "ExportConfigurationResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.ExportConfigurationResponse",
          "fields": [
              {
                  "name": "results",
                  "doc" : "the result of the export",
                  "type": "string"
              },
              {
                  "name": "data",
                  "doc" : "the exported data as a zipped archive i.e. in tar.gz format",
                  "type": "bytes"
              }
          ]
      }
      
      
      ),'com.prosoft.avro.EndDeviceStats': parse_schema({
          "type": "record",
          "name": "EndDeviceStats",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.EndDeviceStats",
          "fields": [
              {
                  "name" : "ip",
                  "doc" : "IP of end device",
                  "type" : "string"
              },
              {
                  "name" : "mac",
                  "doc" : "MAC address of end device",
                  "type" : "string"
              }
          ]
      }
      
      ,NAMED),'com.prosoft.avro.NotifyEndDeviceStats': parse_schema({
          "type": "record",
          "name": "NotifyEndDeviceStats",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.NotifyEndDeviceStats",
          "fields": [
              {
                  "name" : "data",
                  "doc" : "data",
                  "type" : {
                    "type" : "array", 
                    "items" : "com.prosoft.avro.EndDeviceStats"
                  }
              }
          ]
      }
      
      ,NAMED),'com.prosoft.avro.StartRshTransferResponse': parse_schema({
          "type": "record",
          "name": "StartRshTransferResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.StartRshTransferResponse",
          "fields": [
              {
                  "name": "message",
                  "type": ["null", "string"],
                  "default": "null"
              }
          ]
      }
      ),'com.prosoft.avro.FirmwareUpgradeProgress': parse_schema({
          "type": "record",
          "name": "FirmwareUpgradeProgress",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.FirmwareUpgradeProgress",
          "fields": [
              {
                  "name": "message",
                  "type": "string"
              }
          ]
      }
      ),'com.prosoft.avro.FinishFRUploadRequest': parse_schema({
          "type": "record",
          "name": "FinishFRUploadRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.FinishFRUploadRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }),'com.prosoft.avro.TagData': parse_schema({
          "type": "record",
          "name": "TagData",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.TagData",
          "fields": [
      		{
                  "name" : "uid",
                  "doc" : "The Tag unique identifier",
                  "type" : "long"
              },
              {
                  "name" : "data",
                  "doc" : "Tag data",
                  "type" : ["null", "int", "string", "double", "long", "float"],
                  "default" : None
              },
              {
                  "name" : "timestamp",
                  "doc" : "Timestamp for tag data",
                  "type" : "long"
              }
          ]
      }
      
      ,NAMED),'com.prosoft.avro.TagDataNotify': parse_schema({
          "type": "record",
          "name": "TagDataNotify",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.TagDataNotify",
          "fields": [
      
             	 {
                  "name" : "tagData",
                  "doc" : "tag data",
                  "type" : {
                    "type" : "array", 
                    "items" : "com.prosoft.avro.TagData"
                  }
              }
          ]
      }
      
      ,NAMED),'com.prosoft.avro.OpenFileStreamSession': parse_schema({
          "type": "record",
          "name": "OpenFileStreamSession",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.OpenFileStreamSession",
          "fields": [
              {
                  "name" : "streamId",
                  "doc" : "the stream id, should be unique per files endpoint session",
                  "type" : "string"
              }
          ]
      }
      ),'com.prosoft.avro.Diagnostics': parse_schema({
          "type": "record",
          "name": "Diagnostics",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.Diagnostics",
          "fields": [
              {
                  "name" : "category",
                  "doc" : "The diagnostics type (e.g. all, system_info, interfaces, connectivity)",
                  "type" : "string"
              },
              {
                  "name" : "data",
                  "doc" : "The diagnostics data",
                  "type" : ["null", "string"],
                  "default" : None
              }
          ]
      }
      
      ,NAMED),'com.prosoft.avro.NotifyConnectivity': parse_schema({
          "type": "record",
          "name": "NotifyConnectivity",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.NotifyConnectivity",
          "fields": [
              {
                  "name": "diagnostics",
                  "type": "com.prosoft.avro.Diagnostics"
              }
          ]
      },NAMED),'com.prosoft.avro.Configuration': parse_schema({
          "type": "record",
          "name": "Configuration",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.Configuration",
          "fields": [
              {
                  "name" : "module",
                  "doc" : "The configuration module name",
                  "type" : "string"
              }, {
                  "name" : "path",
                  "doc" : "The file path for the configuration",      
                  "type" : ["null", "string"],
                  "default" : None
              },
              {
                  "name" : "data",
                  "doc" : "The configuration data",                  
                  "type" : ["null", "string"],
                  "default" : None
              }
          ]
      }
      
      ,NAMED),'com.prosoft.avro.NotifyConfiguration': parse_schema({
          "type": "record",
          "name": "NotifyConfiguration",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.NotifyConfiguration",
          "fields": [
              {
                  "name": "configurations",
                  "type": {
      				"type" : "array",
      				"items" : "com.prosoft.avro.Configuration"
      			}          
              }
          ]
      },NAMED),'com.prosoft.avro.GetLogsResponse': parse_schema({
          "type": "record",
          "name": "GetLogsResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.GetLogsResponse",
          "fields": [
              {
                  "name": "logs",
                  "type": ["null", "string"],
                  "default": None            
              }
          ]
      }
      ),'com.prosoft.avro.Stats': parse_schema({
          "type": "record",
          "name": "Stats",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.Stats",
          "fields": [
              {
                  "name" : "category",
                  "doc" : "The statistics type (e.g. system, interfaces, etc.)",
                  "type" : "string"
              },
              {
                  "name" : "data",
                  "doc" : "The statistics data",                  
                  "type" : ["null", "string"],
                  "default" : None
              }
          ]
      }
      
      ,NAMED),'com.prosoft.avro.GetStatsResponse': parse_schema({
          "type": "record",
          "name": "GetStatsResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.GetStatsResponse",
          "fields": [
              {
                  "name": "statistics",
                  "type": {
                      "type" : "array",
                      "items" : "com.prosoft.avro.Stats"
                  }
              }
          ]
      }
      ,NAMED),'com.prosoft.avro.ExecCommandResponse': parse_schema({
          "type": "record",
          "name": "ExecCommandResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.ExecCommandResponse",
          "fields": [
              {
                  "name": "stdout",
                  "doc" : "the output of command execution from STDOUT",
                  "type" : ["null", "string"],
                  "default" : None
              },    
              {
                  "name": "stderr",
                  "doc" : "the output of command execution from STDERR",
                  "type" : ["null", "string"],
                  "default" : None
              }
          ]
      }
      ),'com.prosoft.avro.ImportConfigurationRequest': parse_schema({
          "type": "record",
          "name": "ImportConfigurationRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.ImportConfigurationRequest",
          "fields": [
              {
                  "name": "type",
                  "doc" : "the type of data to import",
                  "type": { "type": "enum", "name": "ImportType", "symbols" : ["XML", "TARGZ"]}
              },
              {
                  "name": "data",
                  "doc" : "the data to import",
                  "type": "bytes"        
              },
              {
                  "name": "moduleName",
                  "doc" : "the module name - required if import type is XML",
                  "type": ["null", "string"],
                  "default": None
              }        
          ]
      }
      
      ),'com.prosoft.avro.GenerateSshKeyRequest': parse_schema({
          "type": "record",
          "name": "GenerateSshKeyRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SshKeyRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }
      
      ),'com.prosoft.avro.GetLogsRequest': parse_schema({
          "type": "record",
          "name": "GetLogsRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.GetLogsRequest",
          "fields": [
              {
                  "name": "logType",
                  "doc": "Logs Request type: all, latest",
                  "type": "string",
                  "default": "latest"
              }
          ]
      }
      ),'com.prosoft.avro.GetCredentialsRequest': parse_schema({
          "type": "record",
          "name": "GetCredentialsRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.GetCredentialsRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }
      ),'com.prosoft.avro.SetConfigurationRequest': parse_schema({
      	"type" : "record",
      	"name" : "SetConfigurationRequest",
      	"namespace" : "com.prosoft.avro",
      	"doc" : "Schema for com.prosoft.avro.SetConfigurationRequest",
      	"fields" : [{
      			"name" : "configurations",
                  "doc" : "Applies each configuration. The Configuration module and data are required. The path (full path expected) is used if supplied.",
      			"type" : {
      				"type" : "array",
      				"items" : "com.prosoft.avro.Configuration"
      			}
      		}
      	]
      },NAMED),'com.prosoft.avro.ExecCommand': parse_schema({
          "type": "record",
          "name": "ExecCommand",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.ExecCommand",
          "fields": [
              {
                  "name": "cmd",
                  "type" : {"type": "array", "items": "string"}
              }
          ]
      }
      ),'com.prosoft.avro.SetActivationKeyRequest': parse_schema({
          "type": "record",
          "name": "SetActivationKeyRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SetActivationKeyRequest",
          "fields": [
              {
                  "name": "activationKey",
                  "type": "string"
              },
              {
                  "name": "activationState",
                  "type": {
                      "type": "enum",
                      "name": "ActivationState",
                      "symbols" : ["NOT_ACTIVATED", "ACTIVATED"]
                  }
              }
          ]
      }
      ),'com.prosoft.avro.PacketCaptureResponseAndNotify': parse_schema({
          "type": "record",
          "name": "PacketCaptureResponseAndNotify",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.PacketCaptureResponseAndNotify",
          "fields": [
              {
                  "name": "code",
                  "doc" : "output code of command execution",
                  "type" : ["string"]
              },
              {
                  "name": "status",
                  "doc" : "status output of the command execution",
                  "type" : ["string"]
              },
              {
                  "name": "error",
                  "doc" : "error output of the command execution",
                  "type" : ["null", "string"],
                  "default" : None
              },
              {
                  "name": "seqId",
                  "doc" : "seqId of the command execution",
                  "type" : ["null", "string"],
                  "default" : None
              }
          ]
      }),'com.prosoft.avro.CloseRshSessionResponse': parse_schema({
          "type": "record",
          "name": "CloseRshSessionResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.CloseRshSessionResponse",
          "fields": [
              {
                  "name": "message",
                  "type": ["null", "string"],
                  "default": "null"
              }
          ]
      }
      ),'com.prosoft.avro.SetTerminalSize': parse_schema({
          "type": "record",
          "name": "SetTerminalSize",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SetTerminalSize",
          "fields":[
              {
                  "name" : "streamId",
                  "type" : "string"
              },
              {
                  "name" : "columns",
                  "type" : "int"
              },
              {
                  "name" : "rows",
                  "type" : "int"
              }
          ]
      }
      ),'com.prosoft.avro.ImportConfigurationResponse': parse_schema({
          "type": "record",
          "name": "ImportConfigurationResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.ImportConfigurationResponse",
          "fields": [
              {
                  "name": "result",
                  "doc" : "the result of the import",
                  "type": "string"
              }
          ]
      }
      
      ),'com.prosoft.avro.SDCardIdentifyRequest': parse_schema({
          "type": "record",
          "name": "SDCardIdentifyRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SDCardIdentifyRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }
      ),'com.prosoft.avro.SDCardFSCKRequest': parse_schema({
          "type": "record",
          "name": "SDCardFSCKRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SDCardFSCKRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }),'com.prosoft.avro.CloseRshSession': parse_schema({
          "type": "record",
          "name": "CloseRshSession",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.CloseRshSession",
          "fields": [
              {
                  "name" : "streamId",
                  "doc" : "the stream id, should be unique per streams endpoint session",
                  "type" : "string"
              }
          ]
      }
      ),'com.prosoft.avro.SDCardFormatRequest': parse_schema({
          "type": "record",
          "name": "SDCardFormatRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SDCardFormatRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }),'com.prosoft.avro.StartRshTransfer': parse_schema({
          "type": "record",
          "name": "StartRshTransfer",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.StartRshTransfer",
          "fields": [
              {
                  "name" : "streamId",
                  "doc" : "the stream id, should be unique per streams endpoint session",
                  "type" : "string"
              }
          ]
      }
      ),'com.prosoft.avro.GenerateSshKeyResponse': parse_schema({
          "type": "record",
          "name": "GenerateSshKeyResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.GenerateSshKeyResponse",
          "fields": [
              {
                  "name": "publicKey",
                  "type": "string"
              }
          ]
      }
      ),'com.prosoft.avro.GetDiagnosticsResponse': parse_schema({
          "type": "record",
          "name": "GetDiagnosticsResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.GetDiagnosticsResponse",
          "fields": [
              {
                  "name": "diagnostics",
                  "type": "com.prosoft.avro.Diagnostics"
              }
          ]
      }
      ,NAMED),'com.prosoft.avro.GetConfigurationRequest': parse_schema({
          "type": "record",
          "name": "GetConfigurationRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.GetConfigurationRequest",
          "fields": [
              {
                  "name": "modules",
                  "doc" : "An optional list of module names. If not specified all configurations are returned",
                  "type": ["null", {"type": "array", "items": "string"}],
                  "default": None            
              }
          ]
      }
      ),'com.prosoft.avro.SetCredentialsRequest': parse_schema({
      	"type" : "record",
      	"name" : "SetCredentialsRequest",
      	"namespace" : "com.prosoft.avro",
      	"doc" : "Updates the user, password, or both",
      	"fields" : [
              {
      			"name" : "user",
      			"type" : ["null", "string"],
                  "default" : None
      		},
              {
      			"name" : "password",
                  "doc"  : "base64 encoded password string",
      			"type" : ["null", "string"],
                  "default" : None
      		}
      	]
      }),'com.prosoft.avro.MoveFileRequest': parse_schema({
          "type": "record",
          "name": "MoveFileRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.MoveFileRequest",
          "fields": [
              {
                  "name": "src",
                  "docs": "Path for the file or dir to be moved",
                  "type": "string"
              },
              {
                  "name": "dst",
                  "docs": "Path for the file or dir where will be moved",
                  "type": "string"
              }
          ]
      }),'com.prosoft.avro.GetDiagnosticsRequest': parse_schema({
          "type": "record",
          "name": "GetDiagnosticsRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.GetDiagnosticsRequest",
          "fields": [
              {
                  "name": "category",
                  "docs": "The diagnostics type (e.g. all, system_info, interfaces, connectivity)",
                  "type" : "string",
                  "default": "all"
              }
          ]
      }
      ),'com.prosoft.avro.NotifyCloseTunnel': parse_schema({
          "type": "record",
          "name": "NotifyCloseTunnel",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.NotifyCloseTunnel",
          "fields": [
              {
                  "name": "connectionName",
                  "type" : ["null", "string"],
      			"default": None
              }
          ]
      }
      ),'com.prosoft.avro.RebootResponse': parse_schema({
          "type": "record",
          "name": "RebootResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.RebootResponse",
          "fields": [
              {
                  "name": "message",
                  "type": "string"
              }
          ]
      }
      ),'com.prosoft.avro.RebootRequest': parse_schema({
          "type": "record",
          "name": "RebootRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.RebootRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }),'com.prosoft.avro.CloseFileStreamSession': parse_schema({
          "type": "record",
          "name": "CloseFileStreamSession",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.CloseFileStreamSession",
          "fields": [
              {
                  "name" : "streamId",
                  "doc" : "the stream id, should be unique per files endpoint session",
                  "type" : "string"
              }
          ]
      }
      ),'com.prosoft.avro.SDCardEjectRequest': parse_schema({
          "type": "record",
          "name": "SDCardEjectRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SDCardEjectRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }),'com.prosoft.avro.NotifyCredentials': parse_schema({
          "type": "record",
          "name": "NotifyCredentials",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.NotifyCredentials",
          "fields": [
              {
                  "name": "user",
                  "doc": "the user name",
                  "type": "string"
              }, 
              {
                  "name": "password",
                  "doc": "the encrypted password hash",
                  "type": "string"
              },
              {
                  "name": "salt",
                  "doc": "the salt used for hashing the password",
                  "type": "string"
              }      
          ]
      }),'com.prosoft.avro.NotifyEvent': parse_schema({
          "type": "record",
          "name": "NotifyEvent",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.NotifyEvent",
          "fields": [
              {
                  "name": "data",
                  "type": "string"
              }
          ]
      }),'com.prosoft.avro.CloseTunnelRequest': parse_schema({
          "type": "record",
          "name": "CloseTunnelRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.CloseTunnelRequest",
          "fields": [
              {
                  "name": "connectionName",
                  "type" : ["null", "string"],
                  "default": None
              }
          ]
      }
      ),'com.prosoft.avro.OpenRshSession': parse_schema({
          "type": "record",
          "name": "OpenRshSession",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.OpenRshSession",
          "fields": [
              {
                  "name" : "streamId",
                  "doc" : "the stream id, should be unique per streams endpoint session",
                  "type" : "string"
              }
          ]
      }
      ),'com.prosoft.avro.SDCardStatusRequest': parse_schema({
          "type": "record",
          "name": "SDCardStatusRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SDCardStatusRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }),'com.prosoft.avro.CreateTunnelResponse': parse_schema({
          "type": "record",
          "name": "CreateTunnelResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.CreateTunnelResponse",
          "fields": [
              {
                  "name": "response",
                  "type": "string"
              }
          ]
      }
      ),'com.prosoft.avro.UpdateEndDeviceList': parse_schema({
          "type": "record",
          "name": "UpdateEndDeviceList",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.UpdateEndDeviceList",
          "fields": [
              {
                  "name": "data",
                  "type" : {"type": "array", "items": "string"}
              }
          ]
      }
      ),'com.prosoft.avro.PrepareFRUploadRequest': parse_schema({
          "type": "record",
          "name": "PrepareFRUploadRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.PrepareFRUploadRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }),'com.prosoft.avro.SDCardIdentifyResponse': parse_schema({
          "type": "record",
          "name": "SDCardIdentifyResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SDCardIdentifyResponse",
          "fields": [
              {
                  "name": "cid",
                  "doc": "Card IDentification (CID) register value",
                  "type": {
                      "type": "fixed",
                      "size": 16,
                      "name": "SDCardCID"
                  }
              },
              {
                  "name": "csd",
                  "doc": "Card Specific Data (CSD) register value",
                  "type": {
                      "type": "fixed",
                      "size": 16,
                      "name": "SDCardCSD"
                  }
              },
              {
                  "name": "scr",
                  "doc": "SD Configuration Register (SCR) value",
                  "type": {
                      "type": "fixed",
                      "size": 8,
                      "name": "SDCardSCR"
                  }
              }
          ]
      }
      ),'com.prosoft.avro.SetTerminalSizeResponse': parse_schema({
          "type": "record",
          "name": "SetTerminalSizeResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SetTerminalSizeResponse",
          "fields":[
              {
                  "name" : "streamId",
                  "type" : "string"
              },
              {
                  "name": "message",
                  "type": ["null", "string"],
                  "default": "null"
              }
          ]
      }
      ),'com.prosoft.avro.NotifyStats': parse_schema({
          "type": "record",
          "name": "NotifyStats",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.NotifyStats",
          "fields": [
              {
                  "name": "statistics",
                  "type": {
                      "type" : "array",
                      "items" : "com.prosoft.avro.Stats"
                  }
              }    
          ]
      },NAMED),'com.prosoft.avro.Configuration': parse_schema({
          "type": "record",
          "name": "Configuration",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.Configuration",
          "fields": [
              {
                  "name" : "module",
                  "doc" : "The configuration module name",
                  "type" : "string"
              }, {
                  "name" : "path",
                  "doc" : "The file path for the configuration",      
                  "type" : ["null", "string"],
                  "default" : None
              },
              {
                  "name" : "data",
                  "doc" : "The configuration data",                  
                  "type" : ["null", "string"],
                  "default" : None
              }
          ]
      }
      
      ),'com.prosoft.avro.CloseFileStreamSessionResponse': parse_schema({
          "type": "record",
          "name": "CloseFileStreamSessionResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.CloseFileStreamSessionResponse",
          "fields": [
              {
                  "name": "message",
                  "type": ["null", "string"],
                  "default": "null"
              }
          ]
      }
      ),'com.prosoft.avro.CreateTunnelRequest': parse_schema({
          "type": "record",
          "name": "CreateTunnelRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.CreateTunnelRequest",
          "fields": [
              {
                  "name": "destinationServer",
                  "type": "string"
              },
              {
                  "name": "destinationPort",
                  "type": "string"
              },
              {
                   "name": "connectionName",
                   "type": "string"
              },
              {
                   "name": "tunnelName",
                   "type": "string"
              },
              {
                   "name": "username",
                   "type": "string"
              },
              {
                   "name": "password",
                   "type": "string"
              },
              {
                  "name": "bridgeCommands",
                  "type": ["null", "string"],
                  "default": "null"
              },
              {
                  "name": "connectionType",
                  "type": {
                      "type": "enum",
                      "name": "ConnectionType",
                      "symbols" : ["PDN", "SRA"]
                  },
                  "default": "SRA"
              },
              {
                  "name": "userEmail",
                  "type": ["null", "string"],
                  "default": "null"
              }
          ]
      }
      ),'com.prosoft.avro.SDCardMountRequest': parse_schema({
          "type": "record",
          "name": "SDCardMountRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SDCardMountRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }),'com.prosoft.avro.SshKeyResponse': parse_schema({
          "type": "record",
          "name": "SshKeyResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SshKeyResponse",
          "fields": [
              {
                  "name": "publicKey",
                  "type": "string"
              }
          ]
      }
      ),'com.prosoft.avro.FactoryResetRequest': parse_schema({
          "type": "record",
          "name": "FactoryResetRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.FactoryResetRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }),'com.prosoft.avro.OpenFileStreamSessionResponse': parse_schema({
          "type": "record",
          "name": "OpenFileStreamSessionResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.OpenFileStreamSessionResponse",
          "fields": [
              {
                  "name": "message",
                  "type": ["null", "string"],
                  "default": "null"
              }
          ]
      }
      ),'com.prosoft.avro.GetConfigurationResponse': parse_schema({
          "type": "record",
          "name": "GetConfigurationResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.GetConfigurationResponse",
          "fields": [
              {
                  "name": "configurations",
                  "type" : {
      				"type" : "array",
      				"items" : "com.prosoft.avro.Configuration"
                  }
              }
          ]
      }
      ,NAMED),'com.prosoft.avro.SDCardStatusResponse': parse_schema({
          "type": "record",
          "name": "SDCardStatusResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.SDCardStatusResponse",
          "fields": [
              {
                  "name": "status",
                  "doc": "result of SD card status",
                  "type": {
                      "type": "enum",
                      "name": "SDCardStatus",
                      "symbols" : ["NOT_PRESENT", "MOUNTED", "UNMOUNTED", "UNKNOWN"]
                  }
              },
              {
                  "name": "capacity",
                  "doc": "result of SD card capacity",
                  "type": ["null", "string"],
                  "default" : None
              },
              {
                  "name": "total",
                  "doc": "result of SD card total capacity",
                  "type": ["null", "string"],
                  "default" : None
              }
          ]
      }),'com.prosoft.avro.DetailedStats': parse_schema({
          "type": "record",
          "name": "DetailedStats",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.DetailedStats",
          "fields": [
              {
                  "name" : "cmd",
                  "doc" : "The statistics type (e.g. ports, lan, wan, dio, cellular, wifi etc.)",
                  "type" : "string"
              },
              {
                  "name" : "data",
                  "doc" : "The statistics data",
                  "type" : ["null", "string"],
                  "default" : None
              }
          ]
      }
      
      ,NAMED),'com.prosoft.avro.GetDetailedStatsResponse': parse_schema({
          "type": "record",
          "name": "GetDetailedStatsResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.GetDetailedStatsResponse",
          "fields": [
              {
                  "name": "stats",
                  "type": {
                      "type" : "array",
                      "items" : "com.prosoft.avro.DetailedStats"
                  }
              }
          ]
      }
      ,NAMED),'com.prosoft.avro.TunnelAccessGranted': parse_schema({
      	"type" : "record",
      	"name" : "TunnelAccessGranted",
      	"namespace" : "com.prosoft.avro",
      	"doc" : "Notifies gateway of tunnel access being granted for a user",
      	"fields" : [
              {
      			"name" : "user",
      			"doc"  : "user for which tunnel access was granted",
      			"type" : "string"
      		},
              {
      			"name" : "startTime",
                  "doc"  : "tunnel access start time",
      			"type" : "long"
      		},
      		{
              	"name" : "endTime",
                  "doc"  : "tunnel access end time",
              	"type" : "long"
      		}
      	]
      }),'com.prosoft.avro.CloseTunnelResponse': parse_schema({
          "type": "record",
          "name": "CloseTunnelResponse",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.CloseTunnelResponse",
          "fields": [
              {
                  "name": "response",
                  "type": "string",
      			"default": ""
              }
          ]
      }
      ),'com.prosoft.avro.FirmwareUpgradeRequest': parse_schema({
          "type": "record",
          "name": "FirmwareUpgradeRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.FirmwareUpgradeRequest",
          "fields": [
                   {
                              "name": "desiredFirmwareVersion",
                              "type": ["null", "string"],
                              "default": None
                   },
                   {
                              "name": "downloadUrl",
                              "type": "string"
                   },
                   {
                              "name": "downloadMD5",
                              "type": ["null", "string"],
                              "default": None
                   },
                   {
                              "name": "downloadSize",
                              "type": ["null", "int"],
                              "default": None                         
                   }
          ]
      }),'com.prosoft.avro.ExportConfigurationRequest': parse_schema({
          "type": "record",
          "name": "ExportConfigurationRequest",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.ExportConfigurationRequest",
          "fields": [
              {
                  "name": "empty",
                  "docs": "Empty field for schema compiliers",
                  "type": "null",
                  "default": None
              }
          ]
      }
      ),'com.prosoft.avro.DeactivateAgentNotify': parse_schema({
          "type": "record",
          "name": "DeactivateAgentNotify",
          "namespace": "com.prosoft.avro",
          "doc" : "Schema for com.prosoft.avro.DeactivateAgentNotify",
          "fields": [
              {
                  "name": "empty",
                  "type": "null",
                  "default" : None
              }
          ]
      }),
        'com.nirmata.avro.ClientConnect': parse_schema({
            "namespace": "com.nirmata.avro",
            "type": "record",
            "name": "ClientConnect",
            "fields": [
                {
                    "name": "clientId",
                    "type": "string"
                },
                {
                    "name": "properties",
                    "type": ["null", {"type": "map", "values": "string"}],
        			"default": None
                }
            ]
        }, NAMED),
#        'com.prosoft.avro.SetActivationKeyRequest': parse_schema({
#            "type": "record",
#            "name": "SetActivationKeyRequest",
#            "namespace": "com.prosoft.avro",
#            "doc" : "Schema for com.prosoft.avro.SetActivationKeyRequest",
#            "fields": [
#                {
#                    "name": "activationKey",
#                    "type": "string"
#                },
#                {
#                    "name": "activationState",
#                    "type": {
#                        "type": "enum",
#                        "name": "ActivationState",
#                        "symbols" : ["NOT_ACTIVATED", "ACTIVATED"]
#                    }
#                }
#            ]
#        }, NAMED),
#        'com.prosoft.avro.NotifyEvent': parse_schema({
#            "type": "record",
#            "name": "NotifyEvent",
#            "namespace": "com.prosoft.avro",
#            "doc" : "Schema for com.prosoft.avro.NotifyEvent",
#            "fields": [
#                {
#                    "name": "data",
#                    "type": "string"
#                }
#             ]
#        }, NAMED),
        'com.nirmata.avro.Message': parse_schema({
            "namespace": "com.nirmata.avro",
            "type": "record",
            "name": "Message",
        	"doc" : "A Message is a reusable record that contains message headers and other common fields. Application specific messages are placed in the body",
            "fields": [
                {
                    "name": "sequenceId",            
                    "doc": "a required ID that uniquely identifes a sequence (e.g. Request -> Ack -> Response) of messages",
                    "type": "string"
                },
                {
                    "name": "sequenceState",            
                    "doc": "indicates the state of the message sequence e.g. if more messages are expected",           
                    "type": {"type": "enum", "name": "SequenceState", "symbols" : ["NONE", "PARTIAL", "COMPLETED_SUCCESS", "COMPLETED_FAILED"]},
                    "default": "NONE"
                },
                {
                    "name": "source",            
                    "doc": "optional identifier of the message source",                       
                    "type": ["null", "string"],
                    "default": None
                },          
                {
                    "name": "destination",            
                    "doc": "optional identifier of the message destination",                                   
                    "type": ["null", "string"],
                    "default": None
                },		
                {
                    "name": "timeoutInMilli",            
                    "doc": "optional timeout for a message response or ACK",            
                    "type": [ "null", "long"],
                    "default": None
                },
                {
                    "name": "errorCode",
        			"doc": "Optional error code to use for failure messages",
                    "type": ["null", "string"],
                    "default": None
                },
                {
                    "name": "errorDescription",
        			"doc": "Optional error description for failure messages",			
                    "type": ["null", "string"],
                    "default": None
                },	
                {
                    "name": "type",
                    "type": ["null", "string"],
                    "default": None
                },
                {
                    "name": "body",
                    "type": ["null", "bytes", "com.nirmata.avro.ClientConnect"],
                    "default": None           
                }
            ]
        }, NAMED)

    }

    def __init__(self,
                 parameters: dict):
        """
        Initializes the AVROProtocolBase instance with optional common field values.
        Specific command and its parameters are handled by subclasses.
        """
        self._bodyparameters = parameters['body']
        self._mainparameters = {k: v for k, v in parameters.items() if k != "body"}
        self._bodybytes = BytesIO()
        self._mainbytes = BytesIO()
        schemaless_writer(self._bodybytes, AVROBuilder.PROTOCOL_COMMAND_MAP.get(self._mainparameters['type']), self._bodyparameters)
        tmpparams = self._mainparameters
        tmpparams['body'] = self._bodybytes.getvalue()
        schemaless_writer(self._mainbytes, AVROBuilder.PROTOCOL_COMMAND_MAP.get('com.nirmata.avro.Message'), tmpparams)

    @staticmethod
    def parse(data: bytes):
        """
        Parses a raw byte string received from a websocket into an AVROProtocol instance.
        This class method acts as a factory, determining the concrete protocol type
        and delegating command-specific parsing to the appropriate subclass.
        """
        params = schemaless_reader(BytesIO(data), AVROBuilder.PROTOCOL_COMMAND_MAP.get('com.nirmata.avro.Message'))
        if not params:
            print(f"Unknown packet received %s" %data)
            return None
        elif not params.get("type", None):
            print(f"Got a packet without a type %s" %data)
            return None
        elif params["type"] not in AVROBuilder.PROTOCOL_COMMAND_MAP:
            print(f"Type is unknown: %s" %params['type'])
            return None

        params['body'] = schemaless_reader(BytesIO(params['body']), AVROBuilder.PROTOCOL_COMMAND_MAP.get(params['type']))

        return AVROBuilder(params)
    
    def build(self):
        return self._mainbytes.getvalue()

    def __str__(self):
        ret = ""
        for key, value in self._mainparameters.items():
            if key == 'body':
                continue
            ret += f"\t{key}: {value}\n"
        ret += f"\tbody:\n"
        for key, value in self._bodyparameters.items():
            ret += f"\t\t{key}: {value}\n"

        return ret


def create_avro_packet(parameters):
    """
    Factory function to create an instance of a specific AVRO protocol class
    based on the command name.

    Args:
        command_name (str): The name of the command (e.g., "com.nirmata.avro.ClientConnect").
        **kwargs: Command-specific parameters for the protocol's constructor,
                  including common fields (uuid, mac_address, etc.) and any custom fields.

    Returns:
        AVROProtocolBase: An instance of the requested concrete protocol class.

    Raises:
        ValueError: If an unknown command name is provided.
    """
    protocol_class = AVROBuilder.PROTOCOL_COMMAND_MAP.get(parameters['type'])
    if not protocol_class:
        raise ValueError(f"Unknown AVRO protocol command: '{parameters['type']}'")
    return AVROBuilder(parameters)

def parse_headers(header_list) -> dict[str, str]:
    headers = { 'User-Agent': 'Go-http-client/1.1' }
    if not header_list:
        return headers
    for h in header_list:
        if ":" not in h:
            raise ValueError(f"Invalid header format (expected 'Key: Value'): {h}")
        k, v = h.split(":", 1)
        headers[k.strip()] = v.strip()
    return headers

def make_ssl_context(args) -> Optional[ssl.SSLContext]:
    if args.uri.startswith("wss://"):
        if args.insecure:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            return ctx
        else:
            ctx = ssl.create_default_context()
            return ctx
    return None


async def ws_send(uri: str,
                       host: str,
                       payload: bytes,
                       headers: dict[str, str],
                       ssl_context: Optional[ssl.SSLContext],
                       timeout: Optional[float]) -> None:
    connect_kwargs = {"additional_headers": headers}
    connect_kwargs["host"] = host
    if ssl_context is not None:
        connect_kwargs["ssl"] = ssl_context

    async with websockets.connect(uri, **connect_kwargs) as ws:
        await ws.send(payload.build())

        print(f"✅ Sent ({payload}) {len(payload.build())} bytes")

        if True:
            try:
                resp = await asyncio.wait_for(ws.recv(), timeout=timeout)
            except asyncio.TimeoutError:
                print(f"⌛ No response within {timeout}s")
                return

            if isinstance(resp, bytes):
                print(f"⬇️  Received binary: {len(resp)} bytes")
                print("HEX:", resp.hex())
                response = AVROBuilder.parse(resp)
                print(f"Got back:")
                print(response)
